

**glove-py is an implementation of the GloVe algorithm for learning word vectors from a corpus.** 


## Installation


using pip: `pip install glove-py`.

install with github code :

`git clone git@github.com:f20500909/glove_py.git`

`python3 setup.py install`



using in shell



### Run

with python:
```python
from glove import *

model = Glove(params)
model.train(input_file)
model.to_txt()
words = model.most_similary("one", 10)
print(words)

```

List of available `params` and their default value:

```
help info......
  -input_file               input_file [small_text]
  -log_dir                  a dirctory to save temp file [log/]
  -cofile                   max length of word ngram [cooccur.bin]
  -vocab_file               output vocabulary [vocab.txt]
  -temp_file                temporary file of common occurrence chunk [temp.bin_]
  -embd_file                embedded file[wordvec.txt]
  -vocab_size               vocabulary size to train  [0]
  -max_size                 maximum size to keep in courpus [10000000]
  -min_count                minimum times  [1]
  -window                   the window size to get common occurrence [10]
  -embed_size               embedded size  [80]
  -epoch                    train epoch [1]
  -threads                  train thread [40]
  -memory_limit             memory used to tain (GB) [1]
  -lr                       learning rate [0.05]
  -keep_case                case-sensitive or not [0]
  -symmetric                whether use symmetric when build co-occurrence [1]
```

with shell:
./demo.sh

### Reference

- [GloVe ](https://github.com/stanfordnlp/GloVe)
- [GloVe-cpp](https://github.com/Yevgnen/GloVe-cpp)
- Jeffrey Pennington, Richard Socher, and Christopher D. Manning. 2014. GloVe: Global Vectors for Word Representation.
